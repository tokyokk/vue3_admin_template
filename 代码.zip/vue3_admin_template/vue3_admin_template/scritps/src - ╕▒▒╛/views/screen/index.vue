<template>
    <div>
       <h1>我是数据大屏一级路由组件</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>