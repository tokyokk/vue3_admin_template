<template>
    <div>
         <h1>添加SKU的结构</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>