<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>